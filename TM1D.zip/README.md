# TM1D

Truck Manager starter Android app.

## Features
- App name: TM1D
- Bottom navigation with 4 tabs (Voyages, Maintenance, Expenses, Reports)
- Compose UI
- GitHub Actions workflow for APK builds
