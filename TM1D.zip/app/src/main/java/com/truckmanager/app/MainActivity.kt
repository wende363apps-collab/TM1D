package com.truckmanager.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TM1DApp()
        }
    }
}

@Composable
fun TM1DApp() {
    var selected by remember { mutableStateOf(0) }
    val tabs = listOf("Voyages", "Maintenance", "Expenses", "Reports")

    Scaffold(
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { index, title ->
                    NavigationBarItem(
                        selected = selected == index,
                        onClick = { selected = index },
                        label = { Text(title) },
                        icon = {}
                    )
                }
            }
        }
    ) { innerPadding ->
        when (selected) {
            0 -> Text("Voyages Screen", modifier = Modifier.fillMaxSize())
            1 -> Text("Maintenance Screen", modifier = Modifier.fillMaxSize())
            2 -> Text("Other Expenses Screen", modifier = Modifier.fillMaxSize())
            3 -> Text("Reports Screen", modifier = Modifier.fillMaxSize())
        }
    }
}
